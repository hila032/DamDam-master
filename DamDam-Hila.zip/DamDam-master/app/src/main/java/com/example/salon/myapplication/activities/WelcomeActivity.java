package com.example.salon.myapplication.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.salon.myapplication.R;
import com.example.salon.myapplication.models.AvailableUsersModel;
import com.example.salon.myapplication.models.UsersModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class WelcomeActivity extends AppCompatActivity {

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        TextView email = (TextView) findViewById(R.id.emailWelcome);
        auth = FirebaseAuth.getInstance();
        email.setText(auth.getCurrentUser().getEmail()); //todo: might prodoce nullPointerException

    }

    public void userList(View view) {
        Intent intent = new Intent(WelcomeActivity.this, EnemychoseActivity.class);
        startActivity(intent);
    }

    public void logout(View view) {
        AvailableUsersModel.removeUser(UsersModel.getId());
        UsersModel.signOut();
        Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    public void profile(View view) {
        Intent intent = new Intent(WelcomeActivity.this, ProfileActivity.class);
        startActivity(intent);
    }
}
