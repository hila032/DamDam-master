package com.example.salon.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
private TextView name;
private TextView age;
private Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name = (EditText) findViewById(R.id.nameET);
        age = (EditText) findViewById(R.id.ageET);
        submit = (Button) findViewById(R.id.submit);

    }




    public void submit(View view) {
        String name1 = name.getText().toString();
        String age1 = age.getText().toString();
        Intent intent = new Intent(Main2Activity.this, Main3Activity.class);
        intent.putExtra("name",name1);
        intent.putExtra("age",age1);
        startActivityForResult(intent,RESULT_OK);
    }
}
